"""
Attendance database.

The rule this module enforces, and the reason it exists as its own file
rather than a few INSERT statements inside the camera loop:

    A row in `attendance` means "this named human was physically standing
    in front of the device at this time."

Nothing else may ever create such a row. A recognized face is not enough -
a photo of an employee recognizes perfectly. So `record_attendance()` is
the ONLY write path into that table, and it refuses anything that isn't
both recognized and cleared by liveness + screen-device detection. Failed
attempts go to a completely separate table, `spoof_attempts`, which is an
audit log, not attendance: being in it never counts as being present.

Two tables:

    attendance      - one row per employee per day (first verified
                      check-in wins; later sightings update `last_seen`
                      so you can also see when they were last at the
                      device, without creating a second check-in).
    spoof_attempts  - every refused attempt, with the reason, so HR /
                      security can see that someone tried to sign in
                      "Marwan" from a phone screen at 08:59.

SQLite is used deliberately: zero setup, one file, works on a Raspberry
Pi with no server. If you later move to MySQL/Postgres, only this file
changes - the rest of the project only calls the methods below.
"""

import os
import sqlite3
from datetime import datetime, timedelta

try:
    import config
    _CFG = config
except ImportError:  # pragma: no cover
    _CFG = None


def _cfg(attr, default):
    return getattr(_CFG, attr, default) if _CFG is not None else default


SCHEMA = """
CREATE TABLE IF NOT EXISTS attendance (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT    NOT NULL,
    date           TEXT    NOT NULL,          -- YYYY-MM-DD
    check_in_time  TEXT    NOT NULL,          -- HH:MM:SS
    timestamp      TEXT    NOT NULL,          -- full ISO timestamp
    last_seen      TEXT    NOT NULL,          -- full ISO timestamp, updated on re-sighting
    sightings      INTEGER NOT NULL DEFAULT 1,
    liveness_score REAL,
    method         TEXT,                      -- 'webcam' | 'mobile' | ...
    evidence_path  TEXT,
    UNIQUE (name, date)
);

CREATE TABLE IF NOT EXISTS spoof_attempts (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    claimed_name   TEXT    NOT NULL,          -- whose face was shown ('Unknown' if no match)
    date           TEXT    NOT NULL,
    time           TEXT    NOT NULL,
    timestamp      TEXT    NOT NULL,
    reason         TEXT    NOT NULL,          -- why it was refused, in plain language
    detector       TEXT,                      -- 'bezel' | 'coco:cell phone' | 'liveness' ...
    liveness_score REAL,
    method         TEXT,
    evidence_path  TEXT
);

CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance (date);
CREATE INDEX IF NOT EXISTS idx_spoof_date      ON spoof_attempts (date);
"""


class AttendanceDB:
    def __init__(self, db_path=None):
        self.db_path = db_path or _cfg(
            "ATTENDANCE_DB_PATH",
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "attendance.db"),
        )
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------
    def record_attendance(self, name, liveness_score=None, method="webcam",
                          evidence_path=None, now=None):
        """
        Record a VERIFIED, LIVE check-in.

        Callers must only reach this after the person has been both
        recognized AND confirmed live (see detect_webcam.py /
        mobile_check.py). This method re-checks the obvious failure mode
        anyway - an empty or "Unknown" name can never become attendance.

        Returns a dict:
            status : 'recorded'  - new check-in written
                     'duplicate' - already checked in today; last_seen
                                   and sightings were updated instead
                     'rejected'  - refused (unusable name)
            name, date, check_in_time, sightings, message
        """
        now = now or datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        iso = now.isoformat(timespec="seconds")

        if not name or name.strip().lower() in {"", "unknown"}:
            return {
                "status": "rejected",
                "name": name,
                "date": date_str,
                "check_in_time": None,
                "sightings": 0,
                "message": "No identified employee - nothing recorded.",
            }

        name = name.strip()
        existing = self.conn.execute(
            "SELECT * FROM attendance WHERE name = ? AND date = ?", (name, date_str)
        ).fetchone()

        if existing is not None:
            self.conn.execute(
                "UPDATE attendance SET last_seen = ?, sightings = sightings + 1 WHERE id = ?",
                (iso, existing["id"]),
            )
            self.conn.commit()
            return {
                "status": "duplicate",
                "name": name,
                "date": date_str,
                "check_in_time": existing["check_in_time"],
                "sightings": existing["sightings"] + 1,
                "message": (
                    f"{name} was already checked in today at {existing['check_in_time']}. "
                    "Attendance unchanged; last-seen time updated."
                ),
            }

        self.conn.execute(
            """INSERT INTO attendance
               (name, date, check_in_time, timestamp, last_seen, sightings,
                liveness_score, method, evidence_path)
               VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)""",
            (name, date_str, time_str, iso, iso,
             None if liveness_score is None else float(liveness_score),
             method, evidence_path),
        )
        self.conn.commit()
        return {
            "status": "recorded",
            "name": name,
            "date": date_str,
            "check_in_time": time_str,
            "sightings": 1,
            "message": f"ATTENDANCE RECORDED: {name} - {date_str} {time_str} (verified live person).",
        }

    def log_spoof(self, claimed_name, reason, detector=None, liveness_score=None,
                  method="webcam", evidence_path=None, now=None):
        """
        Record a refused attempt. This is an audit trail only - it never
        marks anyone present.
        """
        now = now or datetime.now()
        self.conn.execute(
            """INSERT INTO spoof_attempts
               (claimed_name, date, time, timestamp, reason, detector,
                liveness_score, method, evidence_path)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (claimed_name or "Unknown",
             now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S"),
             now.isoformat(timespec="seconds"),
             reason, detector,
             None if liveness_score is None else float(liveness_score),
             method, evidence_path),
        )
        self.conn.commit()

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------
    def already_checked_in_today(self, name, now=None):
        now = now or datetime.now()
        row = self.conn.execute(
            "SELECT check_in_time FROM attendance WHERE name = ? AND date = ?",
            (name, now.strftime("%Y-%m-%d")),
        ).fetchone()
        return row["check_in_time"] if row else None

    def attendance_for_date(self, date_str=None):
        date_str = date_str or datetime.now().strftime("%Y-%m-%d")
        rows = self.conn.execute(
            "SELECT * FROM attendance WHERE date = ? ORDER BY check_in_time", (date_str,)
        ).fetchall()
        return [dict(r) for r in rows]

    def spoofs_for_date(self, date_str=None):
        date_str = date_str or datetime.now().strftime("%Y-%m-%d")
        rows = self.conn.execute(
            "SELECT * FROM spoof_attempts WHERE date = ? ORDER BY time", (date_str,)
        ).fetchall()
        return [dict(r) for r in rows]

    def absentees_for_date(self, all_employee_names, date_str=None):
        """
        Employees with no verified check-in on that date.

        Anyone whose photo was shown on a phone but who never appeared in
        person stays in this list - which is the entire point of the
        system, so it's worth reading the query that way: presence has to
        be earned by a live check-in, absence is the default.
        """
        date_str = date_str or datetime.now().strftime("%Y-%m-%d")
        present = {r["name"] for r in self.conn.execute(
            "SELECT name FROM attendance WHERE date = ?", (date_str,)
        ).fetchall()}
        return sorted(n for n in all_employee_names if n not in present)

    def close(self):
        self.conn.close()


def list_registered_employees(known_faces_dir=None):
    """Employee names = the sub-folders of Known_faces/."""
    known_faces_dir = known_faces_dir or _cfg("KNOWN_FACES_DIR", "Known_faces")
    if not os.path.isdir(known_faces_dir):
        return []
    return sorted(
        d for d in os.listdir(known_faces_dir)
        if os.path.isdir(os.path.join(known_faces_dir, d))
    )
