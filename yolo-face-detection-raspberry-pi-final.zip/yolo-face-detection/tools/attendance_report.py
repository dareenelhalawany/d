"""
Attendance report.

Reads attendance.db and prints who was verified present on a given day,
who was absent, and every refused attempt.

Usage:
    python tools/attendance_report.py                 # today
    python tools/attendance_report.py --date 2026-09-08
    python tools/attendance_report.py --csv day.csv   # export the present list
"""

import argparse
import csv
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from attendance import AttendanceDB, list_registered_employees


def main():
    parser = argparse.ArgumentParser(description="Print the attendance report for one day.")
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"),
                        help="Day to report on, YYYY-MM-DD. Defaults to today.")
    parser.add_argument("--csv", default=None, help="Also write the present list to this CSV file.")
    parser.add_argument("--db", default=config.ATTENDANCE_DB_PATH, help="Path to attendance.db")
    args = parser.parse_args()

    db = AttendanceDB(args.db)
    present = db.attendance_for_date(args.date)
    employees = list_registered_employees(config.KNOWN_FACES_DIR)
    absent = db.absentees_for_date(employees, args.date)
    refused = db.spoofs_for_date(args.date)

    print(f"\nATTENDANCE REPORT - {args.date}")
    print("=" * 58)

    print(f"\nPRESENT ({len(present)}) - verified live, in person:")
    if not present:
        print("  (nobody)")
    for row in present:
        score = "n/a" if row["liveness_score"] is None else f"{row['liveness_score']:.2f}"
        print(f"  {row['name']:<14} in {row['check_in_time']}   "
              f"last seen {row['last_seen'][11:19]}   sightings {row['sightings']:<3} "
              f"liveness {score}  via {row['method']}")

    print(f"\nABSENT ({len(absent)}):")
    if not absent:
        print("  (nobody)")
    for name in absent:
        note = ""
        # Calling out the attempted-but-refused case explicitly is the
        # point of the whole system: somebody tried to sign this person
        # in, and the system held the line.
        if any(r["claimed_name"] == name for r in refused):
            note = "   <- someone tried to check this person in with a photo/video"
        print(f"  {name}{note}")

    print(f"\nREFUSED ATTEMPTS ({len(refused)}) - logged only, never counted as attendance:")
    if not refused:
        print("  (none)")
    for row in refused:
        print(f"  {row['time']}  claimed '{row['claimed_name']}'  [{row['detector']}]")
        print(f"            {row['reason']}")
        if row["evidence_path"]:
            print(f"            evidence: {row['evidence_path']}")

    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["name", "date", "check_in_time", "last_seen",
                             "sightings", "liveness_score", "method"])
            for row in present:
                writer.writerow([row["name"], row["date"], row["check_in_time"],
                                 row["last_seen"], row["sightings"],
                                 row["liveness_score"], row["method"]])
        print(f"\nWrote {len(present)} rows to {args.csv}")

    db.close()
    print()


if __name__ == "__main__":
    main()
