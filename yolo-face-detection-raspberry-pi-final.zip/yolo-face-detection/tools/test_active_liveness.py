"""
Active-liveness calibration and sanity check.

Two modes:

1. Simulation (no camera, no models needed) - reproduces the numbers
   quoted in config.py so you can see the separation between a flat image
   being moved and a real 3D head, and see how landmark jitter narrows
   that gap:

       python tools/test_active_liveness.py --simulate

2. Live camera - runs the real blink detector and movement verifier on
   your webcam using InsightFace's 106-point landmarks, and prints the
   numbers live. This is the one to use for calibration:

       python tools/test_active_liveness.py --camera

   Do each of these in front of the camera and write down the numbers:
     a) stand still and blink normally        -> blinks should count, nonrigid low
     b) turn your head slowly left and right  -> nonrigid should rise well above
                                                 MOVEMENT_NONRIGID_THRESHOLD
     c) hold up a printed photo and wave,
        tilt and zoom it                      -> nonrigid must stay BELOW it
     d) hold up a phone playing a video of a
        face that turns its head              -> nonrigid WILL rise (see the note
                                                 in liveness/active.py); this case
                                                 is caught by screen_object.py and
                                                 by CHALLENGE_MODE, not by movement

   Set MOVEMENT_NONRIGID_THRESHOLD between the highest number you saw in
   (c) and the lowest you saw in (b).
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np


def simulate():
    from liveness.active import BlinkDetector, MovementVerifier

    rng = np.random.default_rng(3)
    base = rng.uniform(-0.3, 0.3, (106, 2)).astype(np.float32)
    box = (0, 0, 200, 200)

    print("\nBLINK STATE MACHINE")
    detector = BlinkDetector()
    series = [0.30] * 10 + [0.12, 0.06, 0.13] + [0.30] * 10 + [0.10, 0.05, 0.11] + [0.30] * 8
    for i, value in enumerate(series):
        detector.update(value, now=i * 0.05)
    print(f"  two simulated blinks -> counted {detector.blink_count}")

    still = BlinkDetector()
    for i in range(50):
        still.update(0.284, now=i * 0.05)
    print(f"  still photo          -> counted {still.blink_count}, frozen={still.is_frozen()}")

    print("\nNON-RIGID MOVEMENT (flat image vs real head)")
    def flat(i, points):
        angle = 0.25 * np.sin(i / 4)
        scale = 1 + 0.12 * np.sin(i / 6)
        rot = np.array([[np.cos(angle), -np.sin(angle)],
                        [np.sin(angle), np.cos(angle)]], np.float32) * scale
        shift = np.array([8 * np.sin(i / 3), 6 * np.cos(i / 3)], np.float32)
        return (points - 100) @ rot.T + 100 + shift

    def head(i, points):
        depth = base[:, 0] * 0.9 + 0.25 * (np.abs(base[:, 1]) < 0.05)
        yaw = 0.45 * np.sin(i / 5)
        x = base[:, 0] * np.cos(yaw) + depth * np.sin(yaw) * 0.55
        y = base[:, 1] + 0.03 * np.sin(yaw) * depth
        return np.stack([x, y], 1).astype(np.float32) * 100 + 100

    for jitter in (0.0, 0.3, 0.8, 1.5):
        line = f"  landmark jitter {jitter:>4} px : "
        for label, maker in (("flat image", flat), ("real head", head)):
            verifier = MovementVerifier()
            for i in range(30):
                points = maker(i, base * 100 + 100)
                points = points + rng.normal(0, jitter, points.shape).astype(np.float32)
                verifier.update(points, box, kps5=None, now=i * 0.05)
            line += f"{label} {verifier.best_nonrigid:.3f}   "
        print(line)
    print("\n  Set MOVEMENT_NONRIGID_THRESHOLD between the two columns, closer to")
    print("  the flat-image side, and re-check on your own camera with --camera.\n")


def live():
    import cv2
    from insightface.app import FaceAnalysis

    import config
    from liveness.active import ActiveLivenessGate

    print("Loading InsightFace...")
    app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
    app.prepare(ctx_id=0, det_size=(320, 320))

    camera = cv2.VideoCapture(config.CAMERA_SOURCE)
    if not camera.isOpened():
        print("Could not open the camera.")
        return

    gate = ActiveLivenessGate()
    print("Press Q to quit, R to restart the check.")

    while True:
        ok, frame = camera.read()
        if not ok:
            break

        faces = app.get(frame)
        status = None
        if faces:
            face = max(faces, key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))
            x1, y1, x2, y2 = [int(v) for v in face.bbox]
            status = gate.update(
                landmarks_106=getattr(face, "landmark_2d_106", None),
                kps5=getattr(face, "kps", None),
                box=(x1, y1, x2, y2),
            )
            progress = status["progress"]
            color = (0, 200, 0) if status["satisfied"] else (0, 200, 255)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(frame, status["prompt"], (x1, max(20, y1 - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            cv2.putText(frame,
                        f"blinks {progress['blinks']}/{progress['required_blinks']}  "
                        f"nonrigid {progress['nonrigid']:.3f} "
                        f"(need {progress['nonrigid_required']:.2f})",
                        (10, frame.shape[0] - 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        cv2.imshow("Active liveness calibration", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("r"):
            gate = ActiveLivenessGate()
            print("restarted")

    camera.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--simulate", action="store_true", help="Run the offline simulation.")
    parser.add_argument("--camera", action="store_true", help="Run live on the webcam.")
    args = parser.parse_args()

    if args.camera:
        live()
    else:
        simulate()
