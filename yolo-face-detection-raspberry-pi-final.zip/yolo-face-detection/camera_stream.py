"""
Camera abstraction so detect_webcam.py (and any other script that opens a
camera) does not need an if/else for "webcam vs Raspberry Pi camera"
scattered through the pipeline.

This wraps the engineer's Picamera2.py approach as-is (create_preview_
configuration with format="RGB888", capture_array(), then cv2.cvtColor
RGB2BGR because Picamera2 hands back RGB and OpenCV/YOLO/InsightFace all
expect BGR) inside a class that exposes the same three methods the rest of
this project already calls on a cv2.VideoCapture object:

    camera.isOpened()
    ret, frame = camera.read()
    camera.release()

Nothing downstream of `ret, frame = camera.read()` in detect_webcam.py
changes: this module's job is only to make that line work identically on a
laptop webcam and on the Raspberry Pi CSI camera.
"""

import time

import cv2


class PiCamera2Stream:
    """Drop-in camera object backed by Picamera2, mirroring Picamera2.py."""

    def __init__(self, width=640, height=480):
        try:
            from picamera2 import Picamera2
        except ImportError as exc:
            raise RuntimeError(
                "picamera2 is not installed. On Raspberry Pi OS install it "
                "with: sudo apt install -y python3-picamera2 "
                "(see README / install instructions)."
            ) from exc

        self._picam2 = Picamera2()

        # Same configuration the engineer used in Picamera2.py.
        cam_config = self._picam2.create_preview_configuration(
            main={"size": (width, height), "format": "RGB888"}
        )
        self._picam2.configure(cam_config)
        self._picam2.start()

        # Same warm-up pause used in Picamera2.py so the sensor/AE/AWB
        # settle before the first frame is grabbed.
        time.sleep(0.3)

        self._opened = True

    def isOpened(self):
        return self._opened

    def read(self):
        if not self._opened:
            return False, None
        try:
            frame = self._picam2.capture_array()
        except Exception as exc:  # sensor glitch / camera unplugged mid-run
            print(f"ERROR: Picamera2 capture failed: {exc}")
            return False, None

        # Picamera2 -> RGB, OpenCV (and YOLO/InsightFace downstream) -> BGR.
        # Identical conversion to Picamera2.py.
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        return True, frame

    def set(self, prop_id, value):
        # cv2.VideoCapture.set(...) is called for CAP_PROP_FRAME_WIDTH /
        # HEIGHT in detect_webcam.py. Picamera2's resolution is fixed at
        # configure() time (done in __init__ instead), so this is a no-op
        # kept only so callers don't need a special case.
        return False

    def get(self, prop_id):
        return 0

    def release(self):
        if self._opened:
            try:
                self._picam2.stop()
            except Exception:
                pass
            self._opened = False


# Any of these strings (case-insensitive) passed as --source, or set as
# config.CAMERA_SOURCE, selects the Raspberry Pi camera instead of
# cv2.VideoCapture.
_PICAMERA2_ALIASES = {"picamera2", "picam2", "pi", "picamera"}


def open_camera(source, width=640, height=480):
    """
    Open `source` and return an object exposing isOpened()/read()/set()/
    release(), regardless of whether it's a laptop/USB webcam, a video
    file, or the Raspberry Pi CSI camera.

    - source == "picamera2" (or an alias above)  -> PiCamera2Stream
    - anything else (int index, video/image path) -> cv2.VideoCapture
    """
    if isinstance(source, str) and source.strip().lower() in _PICAMERA2_ALIASES:
        return PiCamera2Stream(width=width, height=height)
    return cv2.VideoCapture(source)
