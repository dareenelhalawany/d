"""
Employee face-recognition + liveness (anti-spoofing) camera app.

Pipeline per frame:
  1. YOLO detects face bounding boxes.
  2. A lightweight IOU tracker gives each detected face a stable ID across
     frames (liveness/tracker.py).
  3. InsightFace computes a recognition embedding for the crop, matched
     against Known_faces/ to get a name.
  4. liveness/screen_object.py asks whether that face is being DISPLAYED
     on something - a phone, tablet, laptop, monitor or printed photo -
     by looking for the device's own edges around it (and, if the
     optional COCO model is present, by detecting the device outright).
  5. LivenessDetector accumulates several frames of evidence per tracked
     face and decides REAL / FAKE (liveness/detector.py). Device evidence
     acts as a veto there: a good-looking face inside a detected phone is
     still FAKE.
  6. ACTIVE liveness (liveness/active.py) requires the person to
     actually DO something before they can be marked present: complete a
     real blink, and move their head in a way a flat surface cannot
     (see that module for why non-rigid motion beats a video replay).
     With config.CHALLENGE_MODE on, the device also issues randomly
     chosen prompts, which a pre-recorded video cannot anticipate.
  7. Attendance is written to attendance.db ONLY when a face has been
     recognized AND verified live AND free of device evidence AND has
     passed the active blink/movement gate, for
     config.ATTENDANCE_CONFIRM_FRAMES consecutive frames. Refused
     attempts go to the spoof_attempts audit table instead - they never
     mark anybody present.

So the two outcomes the company cares about:

  * The real employee stands in front of the camera -> a row appears in
    `attendance` with their name, date and time.
  * Someone holds up that employee's photo/video on a phone, or a print
    -> red "SPOOF" on screen, a row in `spoof_attempts`, and NOTHING in
    `attendance`. The absent employee stays absent.

Run:
    python detect_webcam.py                 # laptop webcam (config.CAMERA_SOURCE)
    python detect_webcam.py --source 1       # a different camera index
    python detect_webcam.py --source video.mp4   # test against a video file
    python detect_webcam.py --source picamera2   # Raspberry Pi CSI camera (Picamera2)
    python detect_webcam.py --show-debug     # per-signal liveness scores on screen
    python detect_webcam.py --no-db          # run without touching the database
    python detect_webcam.py --no-coco        # skip the optional COCO device model

Press Q to quit.
"""

import argparse
import os
import sys
from datetime import datetime

import cv2
import numpy as np
from insightface.app import FaceAnalysis
from ultralytics import YOLO

import config
from camera_stream import open_camera
from attendance import AttendanceDB
from liveness import CocoDeviceDetector, FaceTracker, LivenessDetector
from liveness.active import ActiveLivenessGate
from liveness.screen_object import evaluate_screen_evidence


def load_known_faces(face_app, known_faces_dir):
    """Build the reference embedding gallery from Known_faces/<name>/*.jpg"""
    known_embeddings = []
    known_names = []

    if not os.path.isdir(known_faces_dir):
        print(f"ERROR: Known faces folder not found: {known_faces_dir}")
        sys.exit(1)

    print("KNOWN FOLDER:", os.path.abspath(known_faces_dir))
    print("CONTENTS:", os.listdir(known_faces_dir))

    for person_name in os.listdir(known_faces_dir):
        person_folder = os.path.join(known_faces_dir, person_name)
        if not os.path.isdir(person_folder):
            continue

        for image_name in os.listdir(person_folder):
            image_path = os.path.join(person_folder, image_name)
            image = cv2.imread(image_path)

            if image is None:
                print("Could not read:", image_path)
                continue

            faces = face_app.get(image)
            if len(faces) == 0:
                print("No face found in:", image_path)
                continue

            embedding = faces[0].embedding
            embedding = embedding / np.linalg.norm(embedding)

            known_embeddings.append(embedding)
            known_names.append(person_name)
            print("Loaded:", person_name, "-", image_name)

    if len(known_embeddings) == 0:
        print("ERROR: No known faces found.")
        sys.exit(1)

    print("--------------------------------")
    print("Known faces loaded successfully.")
    print("People:", set(known_names))
    print("--------------------------------")

    return known_embeddings, known_names


def recognize(face_app, face_crop, known_embeddings, known_names):
    """
    Returns (name, kps, landmarks_106) for a face crop.

    kps is the 5-point keypoint set (eyes, nose, mouth corners) used for
    the coarse pose proxies; landmarks_106 is InsightFace's dense 2D
    landmark set, which is what makes a real blink measurement possible -
    5 points can only ever approximate "is the eye open". Both are None
    if recognition failed, and landmarks_106 is None if this insightface
    build doesn't ship the 106-point model, in which case the blink
    check falls back to being unavailable and the gate says so rather
    than silently passing everyone.
    """
    faces = face_app.get(face_crop)
    if len(faces) == 0:
        return "Unknown", None, None

    current_embedding = faces[0].embedding
    current_embedding = current_embedding / np.linalg.norm(current_embedding)

    similarities = [np.dot(current_embedding, known) for known in known_embeddings]
    best_index = int(np.argmax(similarities))
    best_similarity = similarities[best_index]

    name = "Unknown"
    if best_similarity > config.RECOGNITION_SIMILARITY_THRESHOLD:
        name = known_names[best_index]

    kps = getattr(faces[0], "kps", None)
    landmarks_106 = getattr(faces[0], "landmark_2d_106", None)
    return name, kps, landmarks_106


def verdict_color(verdict):
    if verdict == "REAL":
        return (0, 200, 0)      # green
    if verdict == "FAKE":
        return (0, 0, 255)      # red
    return (0, 200, 255)        # amber/orange while analyzing


def draw_result(frame, track, box, name, verdict, score, screen_evidence,
                active_status, show_debug, details):
    x1, y1, x2, y2 = box
    color = verdict_color(verdict)

    device_seen = bool(screen_evidence and screen_evidence.get("detected"))
    sub_label = ""

    if verdict == "REAL" and name != "Unknown":
        if track.attendance_recorded:
            label = f"{name} - ATTENDANCE RECORDED ({score:.2f})"
            sub_label = track.attendance_message
        elif active_status and not active_status["satisfied"]:
            # The face is real-looking and recognized, but the person
            # hasn't proved they're live yet. Show the instruction, not a
            # progress bar toward a check-in that isn't coming.
            label = f"{name} - {active_status['prompt']}"
            progress = active_status["progress"]
            sub_label = (f"blinks {progress['blinks']}/{progress['required_blinks']}  "
                         f"movement {progress['nonrigid']:.2f}/{progress['nonrigid_required']:.2f}")
            color = (0, 200, 255)
        else:
            remaining = max(0, config.ATTENDANCE_CONFIRM_FRAMES - track.consecutive_ok)
            label = f"{name} - LIVE, confirming... ({remaining}) ({score:.2f})"
            sub_label = track.attendance_message
    elif verdict == "REAL":
        label = f"Unrecognized face - REAL, no employee match ({score:.2f})"
    elif verdict == "FAKE" and name != "Unknown":
        # The face MATCHES a known employee, but the evidence says this is
        # a picture OF them - shown on a device or printed - being held up
        # by someone else. Say so explicitly rather than showing a generic
        # spoof label, so it can't be misread as a successful (if slightly
        # uncertain) check-in for that employee.
        if device_seen:
            label = f"SPOOF: {name}'s photo on a {_device_word(screen_evidence)} - NOT PRESENT"
        else:
            label = f"SPOOF: photo of {name} - NOT a live human ({score:.2f})"
        sub_label = "NOT recorded as attending"
    elif verdict == "FAKE":
        label = f"SPOOF DETECTED - not a live human ({score:.2f})"
    else:
        label = f"{name} - Checking liveness..."

    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    cv2.putText(frame, label, (x1, max(20, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.62, color, 2)

    if sub_label:
        cv2.putText(frame, sub_label, (x1, min(frame.shape[0] - 8, y2 + 18)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, color, 1)

    if device_seen:
        cv2.putText(frame, f"DEVICE: {screen_evidence['source']}",
                    (x1, max(38, y1 - 30)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

    if show_debug and details:
        debug_line = " ".join(f"{k}:{v}" for k, v in details.items())
        cv2.putText(frame, debug_line, (x1, min(frame.shape[0] - 5, y2 + 36)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)


def _device_word(screen_evidence):
    """Short human word for the thing that was detected, for the overlay."""
    source = (screen_evidence or {}).get("source", "")
    if source.startswith("coco:"):
        return source.split(":", 1)[1]
    if source == "panel":
        return "screen"
    return "phone/screen/print"


def save_evidence(frame, prefix, name):
    """Write a JPEG of this moment so every database row can be audited."""
    if not getattr(config, "SAVE_EVIDENCE_SNAPSHOTS", False):
        return None
    try:
        os.makedirs(config.EVIDENCE_DIR, exist_ok=True)
        safe_name = "".join(c if c.isalnum() else "_" for c in (name or "unknown"))
        filename = f"{prefix}_{safe_name}_{datetime.now():%Y%m%d_%H%M%S}.jpg"
        path = os.path.join(config.EVIDENCE_DIR, filename)
        cv2.imwrite(path, frame)
        return path
    except Exception as exc:  # noqa: BLE001 - evidence is best-effort, never fatal
        print(f"WARNING: could not save evidence snapshot: {exc}")
        return None


def handle_attendance(db, track, frame, name, verdict, score, screen_evidence,
                      active_status):
    """
    Turn a per-frame verdict into a database decision.

    The gate is deliberately strict and stateful: `consecutive_ok` only
    grows on frames that are recognized AND live AND device-free, and any
    bad frame resets it to zero. A spoof that momentarily scores well
    therefore never accumulates enough clean frames to be written, while
    a real employee standing still clears the counter in about a second.
    """
    if db is None:
        return

    device_seen = bool(screen_evidence and screen_evidence.get("detected"))
    recognized = name != "Unknown"
    # No blink + no real head movement = no attendance, full stop. This
    # is the condition the employee cannot delegate to a photo.
    active_ok = (not config.ACTIVE_LIVENESS_REQUIRED
                 or (active_status is not None and active_status["satisfied"]))

    if verdict == "REAL" and recognized and not device_seen and active_ok:
        track.consecutive_ok += 1
        if (track.consecutive_ok >= config.ATTENDANCE_CONFIRM_FRAMES
                and not track.attendance_recorded):
            evidence_path = save_evidence(frame, "present", name)
            result = db.record_attendance(
                name=name,
                liveness_score=score,
                method="webcam",
                evidence_path=evidence_path,
            )
            track.attendance_recorded = True
            track.attendance_message = (
                f"Recorded {result['date']} {result['check_in_time']}"
                if result["status"] == "recorded"
                else f"Already checked in at {result['check_in_time']}"
            )
            print(result["message"])
        return

    # Anything else resets the streak.
    track.consecutive_ok = 0

    if verdict == "FAKE" and not track.spoof_logged:
        reason = track.spoof_reason or "Liveness check failed."
        if active_status and active_status.get("reason"):
            reason = f"{reason} {active_status['reason']}"
        detector_name = (screen_evidence or {}).get("source", "liveness")
        evidence_path = save_evidence(frame, "spoof", name)
        db.log_spoof(
            claimed_name=name,
            reason=reason,
            detector=detector_name,
            liveness_score=score,
            method="webcam",
            evidence_path=evidence_path,
        )
        track.spoof_logged = True
        who = f"'{name}'" if recognized else "an unrecognized face"
        print(f"SPOOF ATTEMPT REFUSED ({who}): {reason} -> NOT marked present.")


def main():
    parser = argparse.ArgumentParser(description="Employee face recognition + liveness detection")
    parser.add_argument("--source", default=None,
                         help="Camera index, video/image file path, or 'picamera2' for the "
                              "Raspberry Pi CSI camera. Defaults to config.CAMERA_SOURCE.")
    parser.add_argument("--show-debug", action="store_true",
                         help="Overlay individual liveness signal scores on screen.")
    parser.add_argument("--no-db", action="store_true",
                         help="Run detection only; do not write to the attendance database.")
    parser.add_argument("--no-coco", action="store_true",
                         help="Skip the optional COCO phone/laptop/tv detector.")
    parser.add_argument("--challenge", action="store_true",
                         help="Force challenge mode on: the device asks for random "
                              "actions (blink twice, turn head) that a pre-recorded "
                              "video cannot anticipate.")
    parser.add_argument("--no-active", action="store_true",
                         help="Disable the blink/movement requirement (testing only).")
    args = parser.parse_args()

    if args.challenge:
        config.CHALLENGE_MODE = True
    if args.no_active:
        config.ACTIVE_LIVENESS_REQUIRED = False

    source = args.source if args.source is not None else config.CAMERA_SOURCE
    # argparse gives strings; turn plain digits back into an int camera index.
    if isinstance(source, str) and source.isdigit():
        source = int(source)

    # ----------------------------------------------------------------
    # 1. Load models
    # ----------------------------------------------------------------
    print("Loading YOLO face detector...")
    yolo_model = YOLO(config.YOLO_MODEL_PATH)

    print("Loading InsightFace recognition model...")
    face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
    face_app.prepare(ctx_id=0, det_size=(320, 320))

    known_embeddings, known_names = load_known_faces(face_app, config.KNOWN_FACES_DIR)

    coco_detector = None
    if config.USE_COCO_DEVICE_DETECTOR and not args.no_coco:
        print("Loading COCO device detector (phone / laptop / tv / book)...")
        coco_detector = CocoDeviceDetector()
        if coco_detector.available:
            print("Device detector ready.")
        else:
            # Not fatal by design - the geometric screen detection in
            # liveness/screen_object.py still runs without any extra model.
            print(f"NOTE: {coco_detector.load_error}")
            coco_detector = None

    db = None
    if not args.no_db:
        db = AttendanceDB(config.ATTENDANCE_DB_PATH)
        print(f"Attendance database: {db.db_path}")

    tracker = FaceTracker(
        iou_threshold=config.TRACKER_IOU_THRESHOLD,
        max_missed=config.TRACKER_MAX_MISSED,
        history_len=config.LIVENESS_HISTORY_LEN,
    )
    liveness_detector = LivenessDetector(
        min_frames=config.LIVENESS_MIN_FRAMES,
        score_threshold=config.LIVENESS_SCORE_THRESHOLD,
    )

    # ----------------------------------------------------------------
    # 2. Open camera / video source
    # ----------------------------------------------------------------
    # open_camera() (camera_stream.py) returns a plain cv2.VideoCapture for
    # a webcam index / video file / image path, or a PiCamera2Stream (built
    # on the engineer's Picamera2.py) when source == "picamera2". Both
    # expose isOpened()/read()/set()/release(), so nothing below this
    # point needs to know which one it got.
    camera = open_camera(source, config.FRAME_WIDTH, config.FRAME_HEIGHT)
    if not camera.isOpened():
        print(f"ERROR: Could not open source: {source}")
        sys.exit(1)

    camera.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)

    print("Camera started. Press Q to quit.")

    # ----------------------------------------------------------------
    # 3. Main loop
    # ----------------------------------------------------------------
    while True:
        ret, frame = camera.read()
        if not ret:
            print("ERROR: Could not read frame (end of video / camera disconnected).")
            break

        results = yolo_model.predict(source=frame, conf=config.YOLO_CONF_THRESHOLD, verbose=False)
        annotated_frame = frame.copy()

        boxes = []
        for box in results[0].boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            x1 = max(0, x1)
            y1 = max(0, y1)
            x2 = min(frame.shape[1], x2)
            y2 = min(frame.shape[0], y2)
            if x2 - x1 < 10 or y2 - y1 < 10:
                continue
            boxes.append((x1, y1, x2, y2))

        tracks = tracker.update(boxes)

        for track, box in zip(tracks, boxes):
            x1, y1, x2, y2 = box
            face_crop = frame[y1:y2, x1:x2]
            if face_crop.size == 0:
                continue

            name, kps, landmarks_106 = recognize(
                face_app, face_crop, known_embeddings, known_names
            )
            track.name = name

            # Landmarks come back in CROP coordinates; the gate compares
            # them across frames within the same crop frame of reference,
            # which is what the normalization in active.py expects.
            if track.active_gate is None:
                track.active_gate = ActiveLivenessGate()
            crop_box = (0, 0, face_crop.shape[1], face_crop.shape[0])
            active_status = track.active_gate.update(
                landmarks_106=landmarks_106, kps5=kps, box=crop_box
            )

            # Full frame, not the crop: the phone's bezel is by definition
            # outside the face box.
            screen_evidence = evaluate_screen_evidence(frame, box, coco_detector)

            verdict, score, details = liveness_detector.evaluate(
                track, face_crop, kps=kps, screen_evidence=screen_evidence
            )

            handle_attendance(db, track, frame, name, verdict, score,
                              screen_evidence, active_status)

            if args.show_debug:
                details["blinks"] = active_status["progress"]["blinks"]
                details["nonrigid"] = active_status["progress"]["nonrigid"]

            draw_result(annotated_frame, track, box, name, verdict, score,
                        screen_evidence, active_status, args.show_debug,
                        details if args.show_debug else None)

        cv2.imshow("YOLO Face Recognition + Liveness", annotated_frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    camera.release()
    cv2.destroyAllWindows()

    if db is not None:
        today = db.attendance_for_date()
        print("\n--------------------------------")
        print(f"Verified attendance today ({len(today)}):")
        for row in today:
            print(f"  {row['name']:<12} {row['date']}  {row['check_in_time']}")
        refused = db.spoofs_for_date()
        if refused:
            print(f"Refused attempts today ({len(refused)}):")
            for row in refused:
                print(f"  {row['claimed_name']:<12} {row['time']}  [{row['detector']}]")
        print("--------------------------------")
        db.close()


if __name__ == "__main__":
    main()
