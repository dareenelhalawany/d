"""
Blink-based bonus liveness signal.

Uses InsightFace's 5-point landmarks (`face.kps`: left eye, right eye,
nose, left mouth corner, right mouth corner) which are available for
every detected face with no extra model needed.

This is a lightweight, coarse "eye openness" proxy - not a proper
eye-aspect-ratio (that needs a full eyelid contour, e.g. the 106-point
landmark model) - but it's enough to catch the clearest spoof case: a
*static* printed photo held up to the camera, which will never show any
eye-openness change over several seconds, whereas a real person blinks
roughly every 2-6 seconds even when trying to hold still.

Deliberately weighted low in detector.py: it does nothing against a video
replay (a recorded video shows blinking too) - that case is caught by the
frequency/texture/motion signals instead.
"""

import cv2
import numpy as np


def eye_openness_from_kps(gray_face, kps, box):
    """
    gray_face: grayscale crop of the face (same crop the box refers to).
    kps: face.kps from InsightFace - 5 (x, y) points in FULL FRAME coords.
    box: (x1, y1, x2, y2) of the face crop in full frame coords.

    Returns a single float "openness" score, or None if it can't be
    computed (missing landmarks, patch out of bounds).
    """
    if kps is None or len(kps) < 2:
        return None

    x1, y1, x2, y2 = box
    face_w = max(1, x2 - x1)
    patch_h = max(4, int(0.12 * face_w))
    patch_w = max(4, int(0.16 * face_w))

    scores = []
    for (kx, ky) in kps[:2]:  # left eye, right eye
        lx = int(kx - x1 - patch_w / 2)
        ly = int(ky - y1 - patch_h / 2)
        lx = max(0, min(lx, gray_face.shape[1] - 1))
        ly = max(0, min(ly, gray_face.shape[0] - 1))

        patch = gray_face[ly:ly + patch_h, lx:lx + patch_w]
        if patch.size == 0:
            continue

        # Open eyes show a strong eyelid-crease / iris-sclera edge in the
        # vertical direction; closed eyes are comparatively flat.
        gy = cv2.Sobel(patch, cv2.CV_32F, 0, 1, ksize=3)
        scores.append(float(np.mean(np.abs(gy))))

    if not scores:
        return None
    return float(np.mean(scores))


def blink_detected(openness_history, drop_ratio=0.45, min_len=5):
    """
    Looks for a transient dip-and-recover pattern in a track's
    eye-openness history - i.e. a blink. Returns True/False.
    """
    if len(openness_history) < min_len:
        return False

    values = list(openness_history)
    baseline = float(np.median(values))
    if baseline <= 1e-6:
        return False

    low_idx = None
    for i, v in enumerate(values):
        if v < baseline * drop_ratio:
            low_idx = i
            break

    if low_idx is None:
        return False

    after = values[low_idx + 1:]
    if not after:
        return False
    return max(after) > baseline * (1 - (1 - drop_ratio) / 2)
