"""
Display-device detection - "is this face being shown ON something?"

Everything else in this package asks "does this face LOOK real?" (texture,
frequency, motion...). This module asks a different and often much easier
question: "is there a phone / tablet / laptop / monitor / sheet of paper
physically present around that face?"

That matters because the attack this system exists to stop is:

    Employee A doesn't come to work. Employee B stands in front of the
    device holding A's photo on a phone, or a printed photo of A, or
    plays a short video of A. Face recognition matches A, and A gets
    marked present.

A face displayed on a device is almost always surrounded by the physical
edges of that device - a dark bezel, a bright rectangular screen panel, a
hand gripping it, a paper border. Those edges are a strong, *geometric*
cue that is independent of image quality, so it still fires on a
high-resolution phone under good lighting, exactly the case where the
pure texture/frequency signals are weakest.

Two independent detectors here, used together:

1. detect_display_frame()  - geometric, no extra model, always available.
   Looks for a quadrilateral (rectangle seen at an angle) that ENCLOSES
   the face, with device-like proportions and a bezel-like border.

2. CocoDeviceDetector      - semantic, optional. Runs a standard COCO-
   pretrained YOLO model (yolov8n.pt) that already knows the classes
   "cell phone", "laptop", "tv", "book". If the face box sits inside one
   of those boxes, that's about as explicit as evidence gets. Degrades
   silently (returns "no evidence") if the weights aren't present, so
   the system still runs without it.

Both return the same dict shape, described in `no_evidence()`.
"""

import math
import os

import cv2
import numpy as np

try:
    import config
    _CFG = config
except ImportError:  # pragma: no cover - standalone import
    _CFG = None


def _cfg(attr, default):
    return getattr(_CFG, attr, default) if _CFG is not None else default


# ----------------------------------------------------------------------
# Shared result shape
# ----------------------------------------------------------------------
def no_evidence():
    """
    The neutral result. Every function in this module returns this shape:

        detected   : bool  - True = a display device / printed medium was
                             found around the face
        confidence : float 0..1
        source     : str   - which detector fired ("bezel", "coco:cell phone", ...)
        reason     : str   - human-readable, safe to show a user or log
        details    : dict  - per-cue numbers, for --show-debug / tuning
    """
    return {
        "detected": False,
        "confidence": 0.0,
        "source": "none",
        "reason": "",
        "details": {},
    }


def _clip_box(box, shape):
    h, w = shape[:2]
    x1, y1, x2, y2 = box
    return (max(0, int(x1)), max(0, int(y1)), min(w, int(x2)), min(h, int(y2)))


def _box_containment(inner, outer):
    """Fraction of `inner`'s area that lies inside `outer`. 1.0 = fully inside."""
    ix1, iy1, ix2, iy2 = inner
    ox1, oy1, ox2, oy2 = outer

    inter_w = max(0, min(ix2, ox2) - max(ix1, ox1))
    inter_h = max(0, min(iy2, oy2) - max(iy1, oy1))
    inner_area = max(1, (ix2 - ix1) * (iy2 - iy1))
    return (inter_w * inter_h) / inner_area


# ----------------------------------------------------------------------
# 1. Geometric bezel / screen-edge detector (no extra model needed)
# ----------------------------------------------------------------------
def detect_display_frame(frame_bgr, face_box):
    """
    Look for the physical rectangle of a device (or a printed photo /
    sheet of paper) enclosing the given face.

    frame_bgr: the FULL frame, not the face crop - the bezel is by
               definition outside the face box.
    face_box : (x1, y1, x2, y2) of the face in full-frame coords.

    Why a quadrilateral and not a rectangle: a phone held up to a camera
    is essentially never perfectly parallel to the sensor, so its outline
    arrives as a trapezoid. approxPolyDP on the closed edge map handles
    that; a strict axis-aligned rectangle test would miss most real
    attempts.
    """
    result = no_evidence()
    if frame_bgr is None or frame_bgr.size == 0:
        return result

    fh, fw = frame_bgr.shape[:2]
    x1, y1, x2, y2 = _clip_box(face_box, frame_bgr.shape)
    face_w = x2 - x1
    face_h = y2 - y1
    if face_w < 20 or face_h < 20:
        return result

    face_area = float(face_w * face_h)

    # Search window: the device is bigger than the face but not unbounded.
    # A phone held at arm's length puts a face roughly 1/3 to 1/2 the
    # height of the screen, so ~2.6x the face box in each direction
    # comfortably contains the whole device without swallowing the room.
    margin = _cfg("SCREEN_SEARCH_MARGIN", 2.6)
    cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
    half_w = face_w * margin / 2.0
    half_h = face_h * margin / 2.0
    rx1, ry1, rx2, ry2 = _clip_box(
        (cx - half_w, cy - half_h, cx + half_w, cy + half_h), frame_bgr.shape
    )
    roi = frame_bgr[ry1:ry2, rx1:rx2]
    if roi.size == 0 or roi.shape[0] < 40 or roi.shape[1] < 40:
        return result

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Auto Canny thresholds from the median - fixed thresholds break as
    # soon as room lighting changes, which is the whole problem with
    # hard-coded edge detection in an access-control device.
    median = float(np.median(blurred))
    lower = int(max(0, 0.66 * median))
    upper = int(min(255, 1.33 * median))
    edges = cv2.Canny(blurred, lower, upper)

    # Close small gaps so a bezel broken by a finger or glare still forms
    # one continuous contour.
    kernel = np.ones((3, 3), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=2)
    edges = cv2.erode(edges, kernel, iterations=1)

    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return result

    roi_area = float(roi.shape[0] * roi.shape[1])
    face_in_roi = (x1 - rx1, y1 - ry1, x2 - rx1, y2 - ry1)

    best = None
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:12]:
        area = cv2.contourArea(contour)
        # Must be meaningfully bigger than the face (a device holding it)
        # but not the entire search window (that's usually the room).
        if area < face_area * 1.25 or area > roi_area * 0.97:
            continue

        peri = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.035 * peri, True)
        if len(approx) != 4 or not cv2.isContourConvex(approx):
            continue

        quad = approx.reshape(4, 2).astype(np.float32)
        qx1, qy1 = quad[:, 0].min(), quad[:, 1].min()
        qx2, qy2 = quad[:, 0].max(), quad[:, 1].max()
        quad_box = (qx1, qy1, qx2, qy2)

        # The face has to be INSIDE it. A rectangle next to the face is a
        # picture frame on the wall, a door, a monitor in the background -
        # not the thing the face is being displayed on.
        if _box_containment(face_in_roi, quad_box) < 0.85:
            continue

        (_, _), (rect_w, rect_h), _ = cv2.minAreaRect(quad)
        if rect_w < 1 or rect_h < 1:
            continue
        aspect = max(rect_w, rect_h) / min(rect_w, rect_h)

        # Phones/tablets/laptops/printed photos: roughly 1.2:1 to 2.4:1.
        # Anything squarer or longer than that is probably architecture.
        if not (1.10 <= aspect <= 2.60):
            continue

        # How much of the rectangle does the face fill? A face displayed
        # on a screen leaves visible screen around it. A face that fills
        # ~all of the quad is likely just the face's own contour.
        fill = face_area / max(1.0, float(area))
        if fill > 0.80:
            continue

        # Bezel cue: the ring just outside the quad should be markedly
        # darker (phone/tablet/monitor bezel) or markedly different from
        # the bright panel inside it.
        border_contrast = _border_contrast(gray, quad_box)

        # Rectangularity: how well the 4-point approximation explains the
        # contour. A true device edge is crisp; foliage or clothing folds
        # that happen to approximate to 4 points are not.
        rectangularity = area / max(1.0, rect_w * rect_h)
        if rectangularity < 0.80:
            continue

        confidence = (
            0.40 * min(1.0, border_contrast / 28.0)
            + 0.30 * rectangularity
            + 0.30 * min(1.0, (1.0 - fill) / 0.6)
        )
        confidence = float(np.clip(confidence, 0.0, 1.0))

        if best is None or confidence > best["confidence"]:
            best = {
                "confidence": confidence,
                "aspect": round(float(aspect), 2),
                "fill": round(float(fill), 2),
                "border_contrast": round(float(border_contrast), 1),
                "rectangularity": round(float(rectangularity), 2),
            }

    if best is None:
        return result

    threshold = _cfg("SCREEN_BEZEL_CONFIDENCE", 0.55)
    if best["confidence"] < threshold:
        result["details"] = best
        return result

    result.update(
        detected=True,
        confidence=best["confidence"],
        source="bezel",
        reason=(
            "A rectangular device/photo edge was found surrounding this face "
            f"(aspect {best['aspect']}:1, face fills {int(best['fill'] * 100)}% of it) - "
            "the face appears to be displayed on a screen or printed medium, "
            "not standing in front of the camera."
        ),
        details=best,
    )
    return result


def _border_contrast(gray_roi, quad_box):
    """
    Mean-brightness gap between a thin ring just INSIDE the quad edge and
    a thin ring just OUTSIDE it. A phone screen against a room, or a
    bright panel against a black bezel, produces a large gap; a face
    against a wall does not.
    """
    h, w = gray_roi.shape[:2]
    qx1, qy1, qx2, qy2 = [int(v) for v in quad_box]
    qx1, qy1 = max(0, qx1), max(0, qy1)
    qx2, qy2 = min(w, qx2), min(h, qy2)
    if qx2 - qx1 < 10 or qy2 - qy1 < 10:
        return 0.0

    pad = max(3, int(0.04 * min(qx2 - qx1, qy2 - qy1)))

    inner = gray_roi[qy1 + pad:qy2 - pad, qx1 + pad:qx2 - pad]
    if inner.size == 0:
        return 0.0

    outer_mask = np.zeros(gray_roi.shape[:2], dtype=bool)
    ox1, oy1 = max(0, qx1 - pad * 2), max(0, qy1 - pad * 2)
    ox2, oy2 = min(w, qx2 + pad * 2), min(h, qy2 + pad * 2)
    outer_mask[oy1:oy2, ox1:ox2] = True
    outer_mask[qy1:qy2, qx1:qx2] = False
    if not outer_mask.any():
        return 0.0

    return float(abs(inner.mean() - gray_roi[outer_mask].mean()))


# ----------------------------------------------------------------------
# 2. Screen-panel cues that don't depend on seeing the whole bezel
# ----------------------------------------------------------------------
def screen_panel_cues(frame_bgr, face_box):
    """
    Fallback for when the device is held close enough that its edges fall
    outside the camera's view, so detect_display_frame() has no bezel to
    lock onto. Looks at the area immediately AROUND the face for the two
    things a lit panel does and a human head doesn't:

      - a large, flat, near-uniform bright region (backlit panel) with
        very little texture, right up against the face
      - a rectangular specular glare patch (the backlight bouncing off
        the glass back into the lens)

    Returns the standard result dict.
    """
    result = no_evidence()
    if frame_bgr is None or frame_bgr.size == 0:
        return result

    x1, y1, x2, y2 = _clip_box(face_box, frame_bgr.shape)
    face_w, face_h = x2 - x1, y2 - y1
    if face_w < 20 or face_h < 20:
        return result

    pad_w, pad_h = int(face_w * 0.55), int(face_h * 0.55)
    rx1, ry1, rx2, ry2 = _clip_box(
        (x1 - pad_w, y1 - pad_h, x2 + pad_w, y2 + pad_h), frame_bgr.shape
    )
    roi = frame_bgr[ry1:ry2, rx1:rx2]
    if roi.size == 0:
        return result

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    # Surround = the ring around the face inside the ROI.
    surround_mask = np.ones(gray.shape, dtype=bool)
    surround_mask[y1 - ry1:y2 - ry1, x1 - rx1:x2 - rx1] = False
    if surround_mask.sum() < 200:
        return result

    surround = gray[surround_mask]

    # Cue A: flat bright panel. Screens show a big, low-variance,
    # brighter-than-the-face area hugging the head.
    face_gray = gray[y1 - ry1:y2 - ry1, x1 - rx1:x2 - rx1]
    if face_gray.size == 0:
        return result
    brightness_gap = float(surround.mean() - face_gray.mean())
    flatness = float(surround.std())
    panel_cue = 0.0
    if brightness_gap > 18.0 and flatness < 26.0:
        panel_cue = min(1.0, brightness_gap / 55.0) * min(1.0, (26.0 - flatness) / 20.0)

    # Cue B: specular glare blob with a straight-edged (rectangular)
    # shape - glass reflecting a light source or the panel itself.
    glare_cue, glare_area = _rect_glare_cue(gray, surround_mask)

    confidence = float(np.clip(max(panel_cue, glare_cue), 0.0, 1.0))
    details = {
        "brightness_gap": round(brightness_gap, 1),
        "surround_flatness": round(flatness, 1),
        "panel_cue": round(panel_cue, 2),
        "glare_cue": round(glare_cue, 2),
        "glare_area": round(glare_area, 4),
    }

    threshold = _cfg("SCREEN_PANEL_CONFIDENCE", 0.62)
    if confidence < threshold:
        result["details"] = details
        return result

    result.update(
        detected=True,
        confidence=confidence,
        source="panel",
        reason=(
            "A flat, uniformly lit panel (and/or rectangular glass glare) was found "
            "directly around this face - consistent with a phone/tablet/monitor "
            "screen held up to the camera."
        ),
        details=details,
    )
    return result


def _rect_glare_cue(gray_roi, surround_mask):
    """Straight-edged blown-out highlight in the surround -> glass glare."""
    bright = ((gray_roi > 235) & surround_mask).astype(np.uint8) * 255
    area_ratio = float(bright.sum() / 255.0) / max(1.0, float(surround_mask.sum()))
    if area_ratio < 0.006:
        return 0.0, area_ratio

    contours, _ = cv2.findContours(bright, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = 0.0
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < 60:
            continue
        (_, _), (rw, rh), _ = cv2.minAreaRect(contour)
        if rw < 1 or rh < 1:
            continue
        # A glare patch off flat glass fills its bounding rectangle well;
        # a highlight on a nose or forehead is round/irregular and doesn't.
        rectangularity = area / (rw * rh)
        if rectangularity > 0.72:
            best = max(best, min(1.0, rectangularity) * min(1.0, area_ratio / 0.03))
    return float(best), area_ratio


# ----------------------------------------------------------------------
# 3. Optional COCO object detector ("cell phone", "laptop", "tv", "book")
# ----------------------------------------------------------------------
class CocoDeviceDetector:
    """
    Wraps a standard COCO-pretrained YOLO model to answer "is the face
    inside a phone / laptop / TV / book?" directly.

    This is separate from the project's best.pt, which was fine-tuned to
    detect FACES and therefore knows nothing about phones. Loading a
    second, small general model (yolov8n.pt, ~6 MB) is the cheapest way
    to get explicit device labels.

    The weights are NOT bundled. On first use ultralytics downloads
    yolov8n.pt automatically if the machine has internet; on an offline
    Raspberry Pi, copy the file next to config.py beforehand. If it can't
    be loaded, this class disables itself and the geometric detectors
    above carry the load - the system stays functional either way.
    """

    # COCO class names treated as "something a face could be displayed on".
    SPOOF_CLASSES = {
        "cell phone": 1.00,
        "laptop": 0.95,
        "tv": 0.95,
        "book": 0.80,      # covers printed photos / paper held in the hand
        "remote": 0.55,    # phones are often misclassified as this at distance
    }

    def __init__(self, model_path=None, conf=None):
        self.model_path = model_path or _cfg("COCO_MODEL_PATH", "yolov8n.pt")
        self.conf = conf if conf is not None else _cfg("COCO_CONF_THRESHOLD", 0.35)
        self.model = None
        self.available = False
        self.load_error = None
        self._load()

    def _load(self):
        try:
            from ultralytics import YOLO
        except ImportError as exc:  # pragma: no cover
            self.load_error = f"ultralytics not installed ({exc})"
            return

        try:
            self.model = YOLO(self.model_path)
            self.available = True
        except Exception as exc:  # noqa: BLE001 - any failure = fall back quietly
            self.load_error = (
                f"could not load COCO model '{self.model_path}' ({exc}). "
                "Device-class detection is disabled; geometric screen detection "
                "still active."
            )

    def detect(self, frame_bgr, face_box):
        """Returns the standard result dict."""
        result = no_evidence()
        if not self.available or frame_bgr is None:
            return result

        try:
            preds = self.model.predict(source=frame_bgr, conf=self.conf, verbose=False)
        except Exception as exc:  # noqa: BLE001
            self.available = False
            self.load_error = f"COCO inference failed, disabling: {exc}"
            return result

        names = self.model.names
        face = _clip_box(face_box, frame_bgr.shape)

        best = None
        for box in preds[0].boxes:
            label = names[int(box.cls[0])]
            if label not in self.SPOOF_CLASSES:
                continue

            dx1, dy1, dx2, dy2 = map(float, box.xyxy[0])
            containment = _box_containment(face, (dx1, dy1, dx2, dy2))
            # The face must be substantially INSIDE the device. A phone in
            # someone's hand at their side is not a spoof; a face inside a
            # phone-shaped box is.
            if containment < _cfg("COCO_CONTAINMENT_MIN", 0.70):
                continue

            det_conf = float(box.conf[0])
            confidence = det_conf * self.SPOOF_CLASSES[label] * containment
            if best is None or confidence > best[0]:
                best = (confidence, label, det_conf, containment)

        if best is None:
            return result

        confidence, label, det_conf, containment = best
        result.update(
            detected=True,
            confidence=float(np.clip(confidence, 0.0, 1.0)),
            source=f"coco:{label}",
            reason=(
                f"The face is inside a detected '{label}' "
                f"({int(containment * 100)}% enclosed, detector confidence {det_conf:.2f}) - "
                "someone is holding a device/printed image up to the camera instead of "
                "presenting their own face."
            ),
            details={
                "class": label,
                "det_conf": round(det_conf, 2),
                "containment": round(containment, 2),
            },
        )
        return result


# ----------------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------------
def evaluate_screen_evidence(frame_bgr, face_box, coco_detector=None):
    """
    Run every available display-device detector and return the single
    strongest piece of evidence (standard result dict).

    Order matters only for reporting: the COCO detector is checked first
    because "there is a cell phone here" is the most explainable reason
    to give a user or an auditor when a check-in is refused.
    """
    candidates = []

    if coco_detector is not None:
        candidates.append(coco_detector.detect(frame_bgr, face_box))

    candidates.append(detect_display_frame(frame_bgr, face_box))
    candidates.append(screen_panel_cues(frame_bgr, face_box))

    detected = [c for c in candidates if c["detected"]]
    if detected:
        return max(detected, key=lambda c: c["confidence"])

    # Nothing fired - return the most informative "clean" result so the
    # debug overlay still shows the numbers that were considered.
    merged = no_evidence()
    for c in candidates:
        merged["details"].update(c.get("details", {}))
    return merged
