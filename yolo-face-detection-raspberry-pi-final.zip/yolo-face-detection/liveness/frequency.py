"""
Frequency-domain liveness signal (single frame).

This is the strongest single defense against BOTH printed-photo attacks
and phone/tablet video-replay attacks, because it doesn't care whether
the spoof is moving or blinking - it looks for the physical fingerprint
that any "photograph of a flat surface" leaves behind:

 - a phone/monitor screen has a regular sub-pixel grid, which combined
   with the camera's own sensor grid produces a Moire interference
   pattern - a cluster of unnaturally strong, periodic peaks in the
   frequency domain.
 - a printed photo has a halftone dot pattern from the printer, which
   shows up the same way.

A real face, seen directly, has no such periodicity - its frequency
spectrum falls off smoothly from low to high frequencies.
"""

import cv2
import numpy as np


def moire_and_grid_penalty(face_bgr):
    """
    Returns a score in [0, 1]: 1.0 = spectrum looks organic/smooth (more
    likely a real face), 0.0 = strong periodic artifact detected (more
    likely a recaptured screen or print).
    """
    gray = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, (160, 160)).astype(np.float32)

    f = np.fft.fft2(gray)
    fshift = np.fft.fftshift(f)
    magnitude = np.log(np.abs(fshift) + 1.0)

    h, w = magnitude.shape
    cy, cx = h // 2, w // 2

    # Zero out the low-frequency core - every face (real or fake) has
    # strong low-frequency content, that's not informative here.
    core = 6
    ring = magnitude.copy()
    ring[cy - core:cy + core, cx - core:cx + core] = 0

    mean = ring.mean()
    std = ring.std()
    threshold = mean + 3.0 * std
    peak_ratio = float(np.sum(ring > threshold)) / ring.size

    # Empirical reference - recalibrate with tools/calibrate_liveness.py.
    PEAK_REF = 0.010
    penalty = min(peak_ratio / PEAK_REF, 1.0)
    return float(1.0 - penalty)
